package com.mastercrafting.naturaldisasters;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Paquete cliente -> servidor. action: 0 = iniciar desastre id, 1 = detener todo, 2 = romper bloques (id 1 = si, 0 = no). */
public record ControlPayload(int action, int id) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ControlPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(AllNaturalDisasters.MODID, "control"));

    public static final StreamCodec<ByteBuf, ControlPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ControlPayload::action,
            ByteBufCodecs.VAR_INT, ControlPayload::id,
            ControlPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ControlPayload p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer sp)) return;
            boolean holds = sp.getMainHandItem().is(AllNaturalDisasters.CONTROL.get())
                    || sp.getOffhandItem().is(AllNaturalDisasters.CONTROL.get());
            if (!holds && !sp.hasPermissions(2)) return;
            switch (p.action()) {
                case 0 -> {
                    if (p.id() >= 1 && p.id() <= Disasters.ALL.size()) {
                        Def d = Disasters.ALL.get(p.id() - 1);
                        AllNaturalDisasters.begin(sp.serverLevel(), sp.position(), d, d.radius());
                    }
                }
                case 1 -> AllNaturalDisasters.stopAll();
                case 2 -> AllNaturalDisasters.destroyBlocks = p.id() == 1;
                default -> { }
            }
        });
    }
}
