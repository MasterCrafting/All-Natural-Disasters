package com.mastercrafting.naturaldisasters.client;

import com.mastercrafting.naturaldisasters.Categories;
import com.mastercrafting.naturaldisasters.ControlPayload;
import com.mastercrafting.naturaldisasters.Def;
import com.mastercrafting.naturaldisasters.Disasters;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Random;

/** Interfaz: categorias, lista de desastres, ruleta, detener y romper bloques. */
public class ControlScreen extends Screen {
    private static int lastCat = 0;
    private static boolean destroyState = true;

    private final Random rnd = new Random();
    private int cat = lastCat;

    // ruleta
    private boolean spinning = false;
    private int spinTick = 0, nextChange = 0, steps = 0, totalSteps = 0, shown = 0;
    private int hold = -1;

    public ControlScreen() {
        super(Component.literal("All Natural Disasters"));
    }

    private static boolean es() {
        try {
            return Minecraft.getInstance().options.languageCode.startsWith("es");
        } catch (Exception e) {
            return true;
        }
    }

    private static String tr(String es, String en) {
        return es() ? es : en;
    }

    private static String name(Def d) {
        return es() ? d.es() : d.en();
    }

    private boolean busy() {
        return spinning || hold >= 0;
    }

    @Override
    protected void init() {
        int n = Categories.NAMES.length;
        int gap = 4;
        int bw = Math.min(90, (this.width - 20 - gap * (n - 1)) / n);
        int x0 = (this.width - (n * bw + gap * (n - 1))) / 2;
        for (int i = 0; i < n; i++) {
            final int idx = i;
            String label = Categories.NAMES[i][es() ? 0 : 1];
            Button b = Button.builder(Component.literal((i == cat ? "> " : "") + label), btn -> {
                if (busy()) return;
                cat = idx;
                lastCat = idx;
                this.rebuildWidgets();
            }).bounds(x0 + i * (bw + gap), 30, bw, 20).build();
            this.addRenderableWidget(b);
        }

        int[] ids = Categories.IDS[cat];
        for (int j = 0; j < ids.length; j++) {
            Def d = Disasters.ALL.get(ids[j] - 1);
            Button b = Button.builder(Component.literal("#" + d.id() + "  " + name(d)), btn -> {
                if (busy()) return;
                send(0, d.id());
                this.onClose();
            }).bounds(this.width / 2 - 110, 62 + j * 24, 220, 20).build();
            if (es()) b.setTooltip(Tooltip.create(Component.literal(d.descEs())));
            this.addRenderableWidget(b);
        }

        int by = this.height - 28;
        this.addRenderableWidget(Button.builder(Component.literal(tr("Ruleta", "Roulette")), btn -> {
            if (busy()) return;
            startRoulette();
        }).bounds(this.width / 2 - 155, by, 100, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(tr("Detener todo", "Stop all")), btn -> {
            if (busy()) return;
            send(1, 0);
        }).bounds(this.width / 2 - 50, by, 100, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(tr("Romper: ", "Break: ")
                + (destroyState ? tr("SI", "ON") : tr("NO", "OFF"))), btn -> {
            if (busy()) return;
            destroyState = !destroyState;
            send(2, destroyState ? 1 : 0);
            btn.setMessage(Component.literal(tr("Romper: ", "Break: ")
                    + (destroyState ? tr("SI", "ON") : tr("NO", "OFF"))));
        }).bounds(this.width / 2 + 55, by, 100, 20).build());
    }

    private void send(int action, int id) {
        PacketDistributor.sendToServer(new ControlPayload(action, id));
    }

    private void startRoulette() {
        spinning = true;
        spinTick = 0;
        steps = 0;
        nextChange = 2;
        totalSteps = 28 + rnd.nextInt(Disasters.ALL.size());
        shown = rnd.nextInt(Disasters.ALL.size());
    }

    @Override
    public void tick() {
        if (spinning) {
            spinTick++;
            if (spinTick >= nextChange) {
                shown = (shown + 1) % Disasters.ALL.size();
                steps++;
                nextChange = spinTick + 2 + (steps * steps) / 18;
                if (steps >= totalSteps) {
                    spinning = false;
                    hold = 30;
                }
            }
        } else if (hold >= 0) {
            hold--;
            if (hold < 0) {
                send(0, Disasters.ALL.get(shown).id());
                this.onClose();
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, Component.literal(tr("Control de Desastres", "Disaster Controller")),
                this.width / 2, 12, 0xFFFFFF);
        if (busy()) {
            Def d = Disasters.ALL.get(shown);
            int cx = this.width / 2, cy = this.height / 2;
            g.fill(cx - 120, cy - 28, cx + 120, cy + 28, 0xE0000000);
            g.drawCenteredString(this.font, Component.literal(tr("RULETA", "ROULETTE")), cx, cy - 20, 0xFFAA00);
            g.drawCenteredString(this.font, Component.literal("#" + d.id() + "  " + name(d)), cx, cy - 2,
                    spinning ? 0xFFFFFF : 0x55FF55);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
