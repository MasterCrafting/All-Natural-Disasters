# All Natural Disasters (Java) — Version 2 (Forge 1.21.1)

20 desastres numerados del 1 al 20, item de control, interfaz, categorías y ruleta. NO está compilado ni probado en Minecraft.

## Item
**Control de Desastres** (pestaña "All Natural Disasters" del creativo). Receta: diamantes en las esquinas, redstone en cruz y TNT en el centro. Click derecho abre la interfaz: 5 categorías (Geológicos, Clima, Fuego, Tóxicos, Cósmicos), botón Ruleta, Detener todo y Romper SI/NO.

## Compilar desde el móvil (GitHub Actions)
1. Crea un repositorio en github.com y sube TODO el contenido de esta carpeta (incluida la carpeta `.github`).
2. Entra en la pestaña **Actions**; el flujo "build" corre solo (o pulsa *Run workflow*).
3. Al terminar, abre la ejecución y descarga el artefacto **jar** (dentro de un zip).
4. Pon el .jar en la carpeta `mods` de Forge 1.21.1 (21.1.x).
Si falla, copia el error rojo y mándamelo: es normal que haya que ajustar nombres de la API.

## Comandos (requiere ser operador)
- `/disaster list` — lista los 20
- `/disaster <número|nombre> [radio 6-64]` — ej. `/disaster 3` o `/disaster tornado 40`
- `/disaster random`, `/disaster stop`
- `/disaster destroy true|false` — romper/incendiar bloques
- `/disaster damage <0-5>` — multiplicador de daño

## Lista
1 Terremoto · 2 Tornado · 3 Lluvia de Meteoritos · 4 Granizo · 5 Tormenta Eléctrica · 6 Erupción Volcánica · 7 Ola de Calor · 8 Ventisca · 9 Niebla Tóxica · 10 Tsunami · 11 Avalancha · 12 Sumidero · 13 Plaga de Ceniza · 14 Tormenta de Arena · 15 Radiación · 16 Incendio Forestal · 17 Pulso Electromagnético · 18 Agujero Negro · 19 Lluvia Ácida · 20 Impacto de Cometa

Hecho con ayuda de IA (Claude). Master Crafting dirige el mod, decide qué entra y lo prueba.
© Master Crafting. Todos los derechos reservados. Ver LICENSE.txt.
