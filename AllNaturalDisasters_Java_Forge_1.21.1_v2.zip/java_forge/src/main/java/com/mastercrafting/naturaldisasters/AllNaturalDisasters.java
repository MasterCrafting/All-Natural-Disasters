package com.mastercrafting.naturaldisasters;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

/**
 * All Natural Disasters (Java, Forge) - Version 2.
 * Copyright (c) 2025-2026 Master Crafting. Todos los derechos reservados / All rights reserved.
 */
@Mod(AllNaturalDisasters.MODID)
public class AllNaturalDisasters {
    public static final String MODID = "allnaturaldisasters";
    public static final Logger LOGGER = LoggerFactory.getLogger(MODID);

    /** Si es false, los desastres no rompen ni incendian bloques. */
    public static boolean destroyBlocks = true;
    /** Multiplicador del dano (1.0 = normal). */
    public static float damageScale = 1.0f;

    private static final List<Active> RUNNING = new ArrayList<>();

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final RegistryObject<Item> CONTROL = ITEMS.register("control",
            () -> new ControlItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MODID))
                    .icon(() -> new ItemStack(CONTROL.get()))
                    .displayItems((params, output) -> output.accept(CONTROL.get()))
                    .build());

    @SuppressWarnings("removal")
    public AllNaturalDisasters() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(modBus);
        TABS.register(modBus);
        MinecraftForge.EVENT_BUS.addListener(this::onRegisterCommands);
        MinecraftForge.EVENT_BUS.addListener(this::onServerTick);
        MinecraftForge.EVENT_BUS.addListener(this::onServerStopping);
    }

    /** Inicia un desastre y avisa a los jugadores del nivel. */
    public static void begin(ServerLevel level, Vec3 pos, Def def, int radius) {
        RUNNING.add(new Active(def, level, pos, radius));
        Component msg = Component.literal("§c§l#" + def.id() + " " + def.es() + " §r§7(" + def.en() + ")");
        for (ServerPlayer p : level.players()) {
            p.displayClientMessage(msg, true);
        }
    }

    public static int stopAll() {
        int n = RUNNING.size();
        RUNNING.clear();
        return n;
    }

    // ------------------------------------------------------------------ ticks

    private void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (RUNNING.isEmpty()) return;
        Iterator<Active> it = RUNNING.iterator();
        while (it.hasNext()) {
            Active a = it.next();
            try {
                if (a.tick()) {
                    it.remove();
                }
            } catch (Exception e) {
                LOGGER.error("Error en el desastre {}", a.def().key(), e);
                it.remove();
            }
        }
    }

    private void onServerStopping(ServerStoppingEvent event) {
        RUNNING.clear();
    }

    // --------------------------------------------------------------- comandos

    /** Puede usar los comandos: operador, o quien lleve el item de control en la mano. */
    private static boolean allowed(CommandSourceStack src) {
        if (src.hasPermission(2)) return true;
        ServerPlayer p = src.getPlayer();
        return p != null && (p.getMainHandItem().is(CONTROL.get()) || p.getOffhandItem().is(CONTROL.get()));
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(Commands.literal("disaster")
                .requires(AllNaturalDisasters::allowed)
                .then(Commands.literal("list").executes(ctx -> list(ctx.getSource())))
                .then(Commands.literal("stop").executes(ctx -> stop(ctx.getSource())))
                .then(Commands.literal("random").executes(ctx -> {
                    Def def = Disasters.ALL.get(ctx.getSource().getLevel().getRandom().nextInt(Disasters.ALL.size()));
                    return start(ctx.getSource(), def, def.radius());
                }))
                .then(Commands.literal("destroy")
                        .then(Commands.argument("on", BoolArgumentType.bool()).executes(ctx -> {
                            destroyBlocks = BoolArgumentType.getBool(ctx, "on");
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                    "Romper/incendiar bloques: " + (destroyBlocks ? "SI" : "NO")), true);
                            return 1;
                        })))
                .then(Commands.literal("damage")
                        .requires(src -> src.hasPermission(2))
                        .then(Commands.argument("scale", FloatArgumentType.floatArg(0f, 5f)).executes(ctx -> {
                            damageScale = FloatArgumentType.getFloat(ctx, "scale");
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                    "Multiplicador de dano: " + damageScale), true);
                            return 1;
                        })))
                .then(Commands.argument("desastre", StringArgumentType.word())
                        .suggests((ctx, b) -> SharedSuggestionProvider.suggest(suggestions(), b))
                        .executes(ctx -> {
                            Def def = Disasters.find(StringArgumentType.getString(ctx, "desastre"));
                            if (def == null) {
                                ctx.getSource().sendFailure(Component.literal(
                                        "No existe ese desastre. Usa /disaster list"));
                                return 0;
                            }
                            return start(ctx.getSource(), def, def.radius());
                        })
                        .then(Commands.argument("radio", IntegerArgumentType.integer(6, 64)).executes(ctx -> {
                            Def def = Disasters.find(StringArgumentType.getString(ctx, "desastre"));
                            if (def == null) {
                                ctx.getSource().sendFailure(Component.literal(
                                        "No existe ese desastre. Usa /disaster list"));
                                return 0;
                            }
                            return start(ctx.getSource(), def, IntegerArgumentType.getInteger(ctx, "radio"));
                        }))));
    }

    private static Stream<String> suggestions() {
        List<String> s = new ArrayList<>();
        for (Def def : Disasters.ALL) s.add(def.key());
        return s.stream();
    }

    private int start(CommandSourceStack src, Def def, int radius) {
        begin(src.getLevel(), src.getPosition(), def, radius);
        src.sendSuccess(() -> Component.literal("Desastre iniciado: #" + def.id() + " " + def.es()
                + " (" + def.seconds() + " s, radio " + radius + ")"), true);
        return 1;
    }

    private int stop(CommandSourceStack src) {
        int n = stopAll();
        src.sendSuccess(() -> Component.literal("Desastres detenidos: " + n), true);
        return n;
    }

    private int list(CommandSourceStack src) {
        src.sendSuccess(() -> Component.literal("§6All Natural Disasters (Java) — Version 2: " + Disasters.ALL.size() + " desastres"), false);
        for (Def def : Disasters.ALL) {
            src.sendSuccess(() -> Component.literal("§e" + def.id() + ". §f" + def.es()
                    + " §7(" + def.en() + ") — /disaster " + def.key()), false);
        }
        return Disasters.ALL.size();
    }
}
