package com.mastercrafting.naturaldisasters;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Item de control: click derecho abre la interfaz (solo en el cliente). */
public class ControlItem extends Item {
    public ControlItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) {
            com.mastercrafting.naturaldisasters.client.ClientProxy.openControl();
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
