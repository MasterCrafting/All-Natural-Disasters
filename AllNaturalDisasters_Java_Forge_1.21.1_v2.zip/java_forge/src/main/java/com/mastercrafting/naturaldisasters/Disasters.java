package com.mastercrafting.naturaldisasters;

import com.mastercrafting.naturaldisasters.Def.Arch;
import com.mastercrafting.naturaldisasters.Def.Fx;
import com.mastercrafting.naturaldisasters.Def.Impact;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Blocks;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Lista de desastres de la Version 1 (numerados del 1 al 20). */
public final class Disasters {
    private Disasters() {}

    public static final List<Def> ALL = new ArrayList<>();

    private static ParticleOptions dust(net.minecraft.world.level.block.Block b) {
        return new BlockParticleOption(ParticleTypes.FALLING_DUST, b.defaultBlockState());
    }

    private static void add(String key, String es, String en, String desc, Arch arch, Impact impact,
                            int seconds, int radius, float damage,
                            ParticleOptions p1, ParticleOptions p2, Fx... fx) {
        ALL.add(new Def(ALL.size() + 1, key, es, en, desc, arch, impact, seconds, radius, damage, p1, p2, fx));
    }

    static {
        // 1
        add("terremoto", "Terremoto", "Earthquake",
                "Ondas de sacudida que lanzan al aire, agrietan el suelo y hacen 2 corazones por onda.",
                Arch.PULSE, Impact.CRACK, 40, 32, 4f,
                dust(Blocks.DIRT), ParticleTypes.CLOUD,
                new Fx(MobEffects.MOVEMENT_SLOWDOWN, 3, 0));
        // 2
        add("tornado", "Tornado", "Tornado",
                "Un remolino que atrae y lanza a todo lo que toca, con 1 corazon por segundo cerca del centro.",
                Arch.PULL, Impact.NONE, 45, 30, 2f,
                ParticleTypes.CLOUD, ParticleTypes.LARGE_SMOKE,
                new Fx(MobEffects.CONFUSION, 4, 0));
        // 3
        add("meteoritos", "Lluvia de Meteoritos", "Meteor Shower",
                "Rocas en llamas caen del cielo, abren pequenos crateres, incendian y hacen 4 corazones por impacto.",
                Arch.RAIN, Impact.METEOR, 40, 36, 8f,
                ParticleTypes.FLAME, ParticleTypes.LARGE_SMOKE,
                new Fx(MobEffects.WEAKNESS, 4, 0));
        // 4
        add("granizo", "Granizo", "Hailstorm",
                "Bolas de hielo que caen con fuerza, ralentizan con Slowness y hacen 1 corazon por impacto.",
                Arch.RAIN, Impact.FREEZE, 40, 32, 2f,
                ParticleTypes.SNOWFLAKE, ParticleTypes.ITEM_SNOWBALL,
                new Fx(MobEffects.MOVEMENT_SLOWDOWN, 3, 1));
        // 5
        add("tormenta", "Tormenta Electrica", "Thunderstorm",
                "Rayos que caen al azar y hacen 3 corazones por rayo, con fuego en el suelo.",
                Arch.RAIN, Impact.LIGHTNING, 40, 36, 6f,
                ParticleTypes.ELECTRIC_SPARK, ParticleTypes.CLOUD,
                new Fx(MobEffects.BLINDNESS, 2, 0));
        // 6
        add("volcan", "Erupcion Volcanica", "Volcanic Eruption",
                "Bombas de lava caen sobre la zona, prenden fuego, calcinan el suelo y hacen 3 corazones por impacto.",
                Arch.RAIN, Impact.VOLCANO, 45, 34, 6f,
                ParticleTypes.DRIPPING_LAVA, ParticleTypes.LARGE_SMOKE,
                new Fx(MobEffects.MOVEMENT_SLOWDOWN, 2, 0));
        // 7
        add("calor", "Ola de Calor", "Heat Wave",
                "Aire abrasador que quema, da Hunger y hace 1 corazon por segundo.",
                Arch.AURA, Impact.NONE, 50, 40, 2f,
                ParticleTypes.FLAME, ParticleTypes.SMOKE,
                new Fx(MobEffects.HUNGER, 5, 1), new Fx(MobEffects.WEAKNESS, 4, 0));
        // 8
        add("ventisca", "Ventisca", "Blizzard",
                "Nieve y viento helado que ralentizan con Slowness III y hacen 1 corazon por segundo.",
                Arch.AURA, Impact.NONE, 50, 40, 2f,
                ParticleTypes.SNOWFLAKE, ParticleTypes.CLOUD,
                new Fx(MobEffects.MOVEMENT_SLOWDOWN, 4, 2), new Fx(MobEffects.BLINDNESS, 2, 0));
        // 9
        add("niebla", "Niebla Toxica", "Toxic Fog",
                "Una nube venenosa que envenena con Poison y hace 1 corazon por segundo.",
                Arch.ZONE, Impact.NONE, 45, 22, 2f,
                ParticleTypes.WARPED_SPORE, ParticleTypes.SPORE_BLOSSOM_AIR,
                new Fx(MobEffects.POISON, 4, 0), new Fx(MobEffects.CONFUSION, 4, 0));
        // 10
        add("tsunami", "Tsunami", "Tsunami",
                "Olas enormes que empujan lejos y hacen 3 corazones por ola.",
                Arch.PULSE, Impact.NONE, 40, 36, 6f,
                ParticleTypes.SPLASH, ParticleTypes.BUBBLE,
                new Fx(MobEffects.MOVEMENT_SLOWDOWN, 3, 1));
        // 11
        add("avalancha", "Avalancha", "Avalanche",
                "Masas de nieve que caen en bloque, entierran y hacen 3 corazones por impacto.",
                Arch.RAIN, Impact.FREEZE, 35, 30, 6f,
                dust(Blocks.SNOW_BLOCK), ParticleTypes.CLOUD,
                new Fx(MobEffects.MOVEMENT_SLOWDOWN, 4, 2));
        // 12
        add("sumidero", "Sumidero", "Sinkhole",
                "El suelo se abre y se traga todo, atrae hacia el centro y hace 2 corazones por segundo.",
                Arch.PULL, Impact.SINKHOLE, 40, 24, 4f,
                dust(Blocks.DIRT), ParticleTypes.LARGE_SMOKE,
                new Fx(MobEffects.MOVEMENT_SLOWDOWN, 3, 1));
        // 13
        add("ceniza", "Plaga de Ceniza", "Ash Plague",
                "Ceniza espesa que ciega con Blindness y hace 1 corazon por segundo.",
                Arch.ZONE, Impact.NONE, 45, 24, 2f,
                ParticleTypes.ASH, ParticleTypes.LARGE_SMOKE,
                new Fx(MobEffects.BLINDNESS, 3, 0), new Fx(MobEffects.HUNGER, 4, 0));
        // 14
        add("arena", "Tormenta de Arena", "Sandstorm",
                "Viento cargado de arena que ciega, ralentiza y hace 1 corazon por segundo.",
                Arch.AURA, Impact.NONE, 50, 40, 2f,
                dust(Blocks.SAND), ParticleTypes.CLOUD,
                new Fx(MobEffects.BLINDNESS, 2, 0), new Fx(MobEffects.MOVEMENT_SLOWDOWN, 3, 1));
        // 15
        add("radiacion", "Radiacion", "Radiation",
                "Una zona brillante que da Wither y Nausea y hace 1 corazon por segundo.",
                Arch.ZONE, Impact.NONE, 45, 20, 2f,
                ParticleTypes.HAPPY_VILLAGER, ParticleTypes.GLOW,
                new Fx(MobEffects.WITHER, 4, 0), new Fx(MobEffects.CONFUSION, 5, 0));
        // 16
        add("incendio", "Incendio Forestal", "Wildfire",
                "Fuego que salta entre hojas, hierba y madera y hace 2 corazones por segundo.",
                Arch.ZONE, Impact.WILDFIRE, 50, 26, 4f,
                ParticleTypes.FLAME, ParticleTypes.LARGE_SMOKE,
                new Fx(MobEffects.HUNGER, 3, 0));
        // 17
        add("pem", "Pulso Electromagnetico", "Electromagnetic Pulse",
                "Ondas de chispas que dan Nausea y hacen 2 corazones por pulso.",
                Arch.PULSE, Impact.NONE, 40, 30, 4f,
                ParticleTypes.ELECTRIC_SPARK, ParticleTypes.GLOW,
                new Fx(MobEffects.CONFUSION, 4, 0), new Fx(MobEffects.MOVEMENT_SLOWDOWN, 2, 0));
        // 18
        add("agujero", "Agujero Negro", "Black Hole",
                "Una esfera oscura que atrae con fuerza y hace 3 corazones por segundo cerca del centro.",
                Arch.PULL, Impact.NONE, 40, 36, 6f,
                ParticleTypes.PORTAL, ParticleTypes.SQUID_INK,
                new Fx(MobEffects.DARKNESS, 4, 0), new Fx(MobEffects.WEAKNESS, 3, 0));
        // 19
        add("acida", "Lluvia Acida", "Acid Rain",
                "Gotas verdes que envenenan, marchitan hierba y hojas y hacen 1 corazon por impacto.",
                Arch.RAIN, Impact.ACID, 45, 32, 2f,
                ParticleTypes.HAPPY_VILLAGER, ParticleTypes.WARPED_SPORE,
                new Fx(MobEffects.POISON, 3, 0));
        // 20
        add("cometa", "Impacto de Cometa", "Comet Impact",
                "Un cometa helado que cae con fuerza enorme, abre un crater, congela y hace 6 corazones por golpe.",
                Arch.RAIN, Impact.COMET, 25, 18, 12f,
                ParticleTypes.SNOWFLAKE, ParticleTypes.EXPLOSION,
                new Fx(MobEffects.MOVEMENT_SLOWDOWN, 5, 2));
    }

    /** Busca por numero (1-20) o por nombre corto. */
    public static Def find(String text) {
        String t = text.toLowerCase(Locale.ROOT).trim();
        try {
            int n = Integer.parseInt(t);
            if (n >= 1 && n <= ALL.size()) return ALL.get(n - 1);
            return null;
        } catch (NumberFormatException ignored) {
        }
        for (Def d : ALL) if (d.key().equals(t)) return d;
        return null;
    }
}
