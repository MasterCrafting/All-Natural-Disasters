package com.mastercrafting.naturaldisasters.client;

import net.minecraft.client.Minecraft;

/** Solo se carga en el cliente. */
public final class ClientProxy {
    private ClientProxy() {}

    public static void openControl() {
        Minecraft.getInstance().setScreen(new ControlScreen());
    }
}
