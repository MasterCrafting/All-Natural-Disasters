package com.mastercrafting.naturaldisasters;

/** Categorias de la interfaz (ids de los desastres 1-20). */
public final class Categories {
    private Categories() {}

    public static final String[][] NAMES = {
            {"Geológicos", "Geological"},
            {"Clima", "Weather"},
            {"Fuego", "Fire"},
            {"Tóxicos", "Toxic"},
            {"Cósmicos", "Cosmic"}
    };

    public static final int[][] IDS = {
            {1, 12, 6, 11, 10},
            {2, 4, 5, 8, 14},
            {7, 16, 13},
            {9, 15, 19},
            {3, 20, 18, 17}
    };
}
