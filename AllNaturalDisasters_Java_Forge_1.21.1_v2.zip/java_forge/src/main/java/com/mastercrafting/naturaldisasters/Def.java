package com.mastercrafting.naturaldisasters;

import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.world.effect.MobEffect;

/** Definicion de un desastre (datos puros). */
public record Def(
        int id,              // numero del desastre: empieza en 1
        String key,          // nombre corto para escribir en el comando
        String es,           // nombre en espanol
        String en,           // nombre en ingles
        String descEs,       // descripcion corta
        Arch arch,           // tipo de comportamiento
        Impact impact,       // que hace al caer / golpear
        int seconds,         // duracion
        int radius,          // radio por defecto
        float damage,        // dano por golpe en puntos de vida (2 = un corazon)
        ParticleOptions p1,  // particula principal
        ParticleOptions p2,  // particula secundaria
        Fx[] fx              // efectos de pocion
) {
    /** Efecto de pocion que se aplica a quien recibe el golpe. */
    public record Fx(Holder<MobEffect> effect, int seconds, int amp) {}

    public enum Arch {
        AURA,   // rodea a los jugadores cercanos
        RAIN,   // cae del cielo
        PULSE,  // ondas que se expanden
        ZONE,   // zona fija con efectos
        PULL    // atrae hacia un centro
    }

    public enum Impact {
        NONE, CRATER, FIRE, FREEZE, ACID, LIGHTNING, CRACK, SINKHOLE, WILDFIRE, METEOR, VOLCANO, COMET
    }
}
