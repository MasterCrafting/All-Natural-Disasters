package com.mastercrafting.naturaldisasters;

import com.mastercrafting.naturaldisasters.Def.Arch;
import com.mastercrafting.naturaldisasters.Def.Fx;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Un desastre en marcha. Se avanza una vez por tick del servidor. */
public final class Active {
    private final Def def;
    private final ServerLevel level;
    private final Vec3 center;
    private final int radius;
    private final int totalTicks;
    private final RandomSource rnd;
    private int ticks = 0;

    // lluvia
    private static final class Drop {
        double x, y, z;
        int groundY;
    }
    private final List<Drop> drops = new ArrayList<>();

    // pulsos
    private double ringR = -1;

    public Active(Def def, ServerLevel level, Vec3 center, int radius) {
        this.def = def;
        this.level = level;
        this.center = center;
        this.radius = Math.max(6, Math.min(64, radius));
        this.totalTicks = def.seconds() * 20;
        this.rnd = level.getRandom();
    }

    public Def def() { return def; }

    /** @return true cuando ya termino. */
    public boolean tick() {
        ticks++;
        if (ticks > totalTicks && drops.isEmpty()) return true;
        boolean running = ticks <= totalTicks;
        switch (def.arch()) {
            case AURA -> { if (running) aura(); }
            case RAIN -> rain(running);
            case PULSE -> { if (running) pulse(); }
            case ZONE -> { if (running) zone(); }
            case PULL -> { if (running) pull(); }
        }
        return false;
    }

    // ---------------------------------------------------------------- ayudas

    private boolean destroy() { return AllNaturalDisasters.destroyBlocks; }

    private int surfaceY(int x, int z) {
        return level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
    }

    private void particles(net.minecraft.core.particles.ParticleOptions p, double x, double y, double z,
                           int count, double dx, double dy, double dz, double speed) {
        level.sendParticles(p, x, y, z, count, dx, dy, dz, speed);
    }

    private boolean canBreak(BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        if (s.isAir()) return false;
        float h = s.getDestroySpeed(level, pos);
        if (h < 0 || h >= 40) return false;
        return level.getBlockEntity(pos) == null;
    }

    private List<LivingEntity> near(double x, double y, double z, double r, double up, double down) {
        AABB box = new AABB(x - r, y - down, z - r, x + r, y + up, z + r);
        return level.getEntitiesOfClass(LivingEntity.class, box,
                e -> e.isAlive() && !(e instanceof ArmorStand));
    }

    private boolean protectedPlayer(LivingEntity e) {
        return e instanceof Player p && (p.isCreative() || p.isSpectator());
    }

    private void hit(LivingEntity e, float amount) {
        if (protectedPlayer(e)) return;
        if (amount > 0) {
            float dmg = Math.max(1f, Math.min(6f, amount * AllNaturalDisasters.damageScale));
            e.hurt(level.damageSources().magic(), dmg);
        }
        for (Fx f : def.fx()) {
            e.addEffect(new MobEffectInstance(f.effect(), f.seconds() * 20, f.amp()));
        }
    }

    private void sound(net.minecraft.sounds.SoundEvent s, double x, double y, double z, float vol, float pitch) {
        level.playSound(null, x, y, z, s, SoundSource.WEATHER, vol, pitch);
    }

    // ---------------------------------------------------------------- AURA

    private void aura() {
        double r2 = (double) radius * radius;
        for (ServerPlayer p : level.players()) {
            double dx = p.getX() - center.x, dz = p.getZ() - center.z;
            if (dx * dx + dz * dz > r2 * 2.25) continue;
            if (ticks % 2 == 0) {
                particles(def.p1(), p.getX(), p.getY() + 1.5, p.getZ(), 10, 6, 3, 6, 0.05);
                particles(def.p2(), p.getX(), p.getY() + 1.5, p.getZ(), 3, 6, 3, 6, 0.02);
            }
            if (ticks % 20 == 0 && !protectedPlayer(p)) {
                hit(p, def.damage());
                if (def.key().equals("calor")) p.setRemainingFireTicks(40);
                if (def.key().equals("ventisca")) p.setTicksFrozen(Math.min(p.getTicksRequiredToFreeze() + 20, p.getTicksFrozen() + 60));
            }
        }
        if (ticks % 80 == 1) {
            for (ServerPlayer p : level.players()) {
                sound(SoundEvents.LIGHTNING_BOLT_THUNDER, p.getX(), p.getY(), p.getZ(), 0.15f, 0.5f);
            }
        }
    }

    // ---------------------------------------------------------------- ZONA

    private void zone() {
        if (ticks % 3 == 0) {
            for (int i = 0; i < 2; i++) {
                double a = rnd.nextDouble() * Math.PI * 2, d = Math.sqrt(rnd.nextDouble()) * radius;
                double x = center.x + Math.cos(a) * d, z = center.z + Math.sin(a) * d;
                double y = surfaceY((int) x, (int) z) + rnd.nextDouble() * 4;
                particles(def.p1(), x, y, z, 6, 1.5, 1.2, 1.5, 0.02);
                particles(def.p2(), x, y, z, 2, 1.0, 1.0, 1.0, 0.02);
            }
        }
        if (ticks % 20 == 0) {
            for (LivingEntity e : near(center.x, center.y, center.z, radius, 24, 24)) {
                double dx = e.getX() - center.x, dz = e.getZ() - center.z;
                if (dx * dx + dz * dz <= (double) radius * radius) hit(e, def.damage());
            }
        }
        if (ticks % 10 == 0 && def.impact() == Def.Impact.WILDFIRE) wildfire();
    }

    private void wildfire() {
        for (int i = 0; i < 5; i++) {
            double a = rnd.nextDouble() * Math.PI * 2, d = Math.sqrt(rnd.nextDouble()) * radius;
            int x = (int) (center.x + Math.cos(a) * d), z = (int) (center.z + Math.sin(a) * d);
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
            BlockPos below = new BlockPos(x, y - 1, z);
            BlockState s = level.getBlockState(below);
            boolean burnable = s.is(BlockTags.LEAVES) || s.is(Blocks.GRASS_BLOCK) || s.is(BlockTags.LOGS)
                    || s.is(BlockTags.PLANKS) || s.is(BlockTags.WOOL);
            if (burnable && destroy()) {
                BlockPos at = new BlockPos(x, y, z);
                if (level.getBlockState(at).isAir()) level.setBlockAndUpdate(at, Blocks.FIRE.defaultBlockState());
            }
        }
        for (LivingEntity e : near(center.x, center.y, center.z, radius, 24, 24)) {
            if (!protectedPlayer(e) && rnd.nextInt(4) == 0) e.setRemainingFireTicks(60);
        }
    }

    // ---------------------------------------------------------------- LLUVIA

    private void rain(boolean running) {
        if (running) {
            int perTick = Math.max(1, radius / 14);
            if (def.impact() == Def.Impact.COMET) perTick = (ticks % 100 == 1) ? 1 : 0;
            for (int i = 0; i < perTick && drops.size() < 60; i++) {
                if (rnd.nextInt(2) != 0 && def.impact() != Def.Impact.COMET) continue;
                Drop d = new Drop();
                double a = rnd.nextDouble() * Math.PI * 2, dist = Math.sqrt(rnd.nextDouble()) * radius;
                d.x = center.x + Math.cos(a) * dist;
                d.z = center.z + Math.sin(a) * dist;
                d.groundY = surfaceY((int) d.x, (int) d.z);
                d.y = d.groundY + 40;
                drops.add(d);
            }
        }
        double speed = def.impact() == Def.Impact.COMET ? 1.4 : 2.0;
        Iterator<Drop> it = drops.iterator();
        while (it.hasNext()) {
            Drop d = it.next();
            d.y -= speed;
            particles(def.p1(), d.x, d.y, d.z, def.impact() == Def.Impact.COMET ? 8 : 2, 0.15, 0.4, 0.15, 0.01);
            if (def.impact() == Def.Impact.COMET) particles(def.p2(), d.x, d.y, d.z, 1, 0.3, 0.3, 0.3, 0.01);
            if (d.y <= d.groundY + 0.5) {
                impact(d.x, d.groundY, d.z);
                it.remove();
            }
        }
    }

    private void impact(double x, int gy, double z) {
        boolean big = def.impact() == Def.Impact.COMET;
        double hitR = big ? 7 : 3;
        particles(def.p2(), x, gy + 0.5, z, big ? 40 : 12, hitR * 0.5, 0.6, hitR * 0.5, 0.08);
        particles(def.p1(), x, gy + 0.5, z, big ? 40 : 10, hitR * 0.5, 0.8, hitR * 0.5, 0.1);

        switch (def.impact()) {
            case LIGHTNING -> {
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
                if (bolt != null) {
                    bolt.moveTo(x, gy, z);
                    bolt.setVisualOnly(true);
                    level.addFreshEntity(bolt);
                }
                fireAt(x, gy, z, 2);
            }
            case METEOR -> {
                sound(SoundEvents.FIRECHARGE_USE, x, gy, z, 1.2f, 0.6f);
                level.explode(null, x, gy + 0.5, z, 1.2f, Level.ExplosionInteraction.NONE);
                crater(x, gy, z, 2);
                fireAt(x, gy, z, 2);
            }
            case VOLCANO -> {
                sound(SoundEvents.FIRECHARGE_USE, x, gy, z, 1.0f, 0.5f);
                fireAt(x, gy, z, 2);
                if (destroy()) {
                    BlockPos g = new BlockPos((int) Math.floor(x), gy - 1, (int) Math.floor(z));
                    if (canBreak(g)) level.setBlockAndUpdate(g, Blocks.MAGMA_BLOCK.defaultBlockState());
                }
            }
            case COMET -> {
                sound(SoundEvents.LIGHTNING_BOLT_THUNDER, x, gy, z, 3f, 0.5f);
                level.explode(null, x, gy + 0.5, z, 3f, Level.ExplosionInteraction.NONE);
                crater(x, gy, z, 4);
                snow(x, gy, z, 6);
            }
            case FREEZE -> snow(x, gy, z, 2);
            case ACID -> acid(x, gy, z, 2);
            default -> { }
        }
        for (LivingEntity e : near(x, gy, z, hitR, 6, 3)) {
            double dx = e.getX() - x, dz = e.getZ() - z;
            if (dx * dx + dz * dz <= hitR * hitR) hit(e, def.damage());
        }
    }

    private void crater(double x, int gy, double z, int r) {
        if (!destroy()) return;
        int cx = (int) Math.floor(x), cz = (int) Math.floor(z);
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int dy = -r; dy <= 1; dy++) {
                    if (dx * dx + dz * dz + dy * dy > r * r + 1) continue;
                    BlockPos p = new BlockPos(cx + dx, gy - 1 + dy, cz + dz);
                    if (canBreak(p)) level.setBlockAndUpdate(p, Blocks.AIR.defaultBlockState());
                }
            }
        }
    }

    private void fireAt(double x, int gy, double z, int r) {
        if (!destroy()) return;
        for (int i = 0; i < 3; i++) {
            int px = (int) Math.floor(x) + rnd.nextInt(2 * r + 1) - r;
            int pz = (int) Math.floor(z) + rnd.nextInt(2 * r + 1) - r;
            int py = surfaceY(px, pz);
            BlockPos p = new BlockPos(px, py, pz);
            if (level.getBlockState(p).isAir() && Blocks.FIRE.defaultBlockState().canSurvive(level, p)) {
                level.setBlockAndUpdate(p, Blocks.FIRE.defaultBlockState());
            }
        }
    }

    private void snow(double x, int gy, double z, int r) {
        if (!destroy()) return;
        int cx = (int) Math.floor(x), cz = (int) Math.floor(z);
        for (int i = 0; i < 6; i++) {
            int px = cx + rnd.nextInt(2 * r + 1) - r, pz = cz + rnd.nextInt(2 * r + 1) - r;
            int py = surfaceY(px, pz);
            BlockPos p = new BlockPos(px, py, pz);
            if (level.getBlockState(p).isAir() && Blocks.SNOW.defaultBlockState().canSurvive(level, p)) {
                level.setBlockAndUpdate(p, Blocks.SNOW.defaultBlockState());
            }
        }
    }

    private void acid(double x, int gy, double z, int r) {
        if (!destroy()) return;
        int cx = (int) Math.floor(x), cz = (int) Math.floor(z);
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int px = cx + dx, pz = cz + dz;
                BlockPos g = new BlockPos(px, surfaceY(px, pz) - 1, pz);
                BlockState s = level.getBlockState(g);
                if (s.is(Blocks.GRASS_BLOCK)) level.setBlockAndUpdate(g, Blocks.DIRT.defaultBlockState());
                BlockPos t = new BlockPos(px, level.getHeight(Heightmap.Types.MOTION_BLOCKING, px, pz) - 1, pz);
                if (level.getBlockState(t).is(BlockTags.LEAVES) && rnd.nextInt(3) == 0) {
                    level.setBlockAndUpdate(t, Blocks.AIR.defaultBlockState());
                }
            }
        }
    }

    // ---------------------------------------------------------------- PULSOS

    private void pulse() {
        if (ringR < 0) {
            if (ticks % 40 == 1) {
                ringR = 1;
                sound(SoundEvents.LIGHTNING_BOLT_THUNDER, center.x, center.y, center.z, 2f, 0.4f);
                if (def.key().equals("terremoto")) {
                    for (LivingEntity e : near(center.x, center.y, center.z, radius, 12, 12)) {
                        if (protectedPlayer(e)) continue;
                        e.setDeltaMovement(e.getDeltaMovement().add((rnd.nextDouble() - 0.5) * 0.4, 0.45, (rnd.nextDouble() - 0.5) * 0.4));
                        e.hurtMarked = true;
                    }
                }
            }
            return;
        }
        ringR += 1.6;
        int n = (int) Math.min(48, Math.max(12, ringR * 4));
        for (int i = 0; i < n; i++) {
            double a = (Math.PI * 2 * i) / n;
            double x = center.x + Math.cos(a) * ringR, z = center.z + Math.sin(a) * ringR;
            double y = surfaceY((int) x, (int) z) + 0.4;
            particles(def.p1(), x, y, z, 1, 0.2, 0.5, 0.2, 0.05);
            if (i % 3 == 0) particles(def.p2(), x, y + 0.5, z, 1, 0.3, 0.6, 0.3, 0.03);
        }
        for (LivingEntity e : near(center.x, center.y, center.z, ringR + 3, 10, 6)) {
            double dx = e.getX() - center.x, dz = e.getZ() - center.z;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (Math.abs(dist - ringR) <= 2.5 && dist <= radius + 3) {
                hit(e, def.damage());
                if (!protectedPlayer(e) && dist > 0.1) {
                    Vec3 push = new Vec3(dx / dist * 0.8, 0.35, dz / dist * 0.8);
                    e.setDeltaMovement(e.getDeltaMovement().add(push));
                    e.hurtMarked = true;
                }
            }
        }
        if (def.impact() == Def.Impact.CRACK && destroy()) crack();
        if (ringR >= radius) ringR = -1;
    }

    private void crack() {
        for (int i = 0; i < 4; i++) {
            double a = rnd.nextDouble() * Math.PI * 2;
            int x = (int) (center.x + Math.cos(a) * ringR), z = (int) (center.z + Math.sin(a) * ringR);
            BlockPos g = new BlockPos(x, surfaceY(x, z) - 1, z);
            BlockState s = level.getBlockState(g);
            if (s.is(Blocks.STONE)) level.setBlockAndUpdate(g, Blocks.COBBLESTONE.defaultBlockState());
            else if (s.is(Blocks.DIRT) || s.is(Blocks.GRASS_BLOCK)) level.setBlockAndUpdate(g, Blocks.COARSE_DIRT.defaultBlockState());
            else if (s.is(Blocks.COBBLESTONE)) level.setBlockAndUpdate(g, Blocks.GRAVEL.defaultBlockState());
        }
    }

    // ---------------------------------------------------------------- ATRACCION

    private void pull() {
        double angle = ticks * 0.35;
        for (int i = 0; i < 4; i++) {
            double h = (ticks * 0.5 + i * 6) % 24;
            double rr = 2 + h * 0.5;
            double a = angle + i * Math.PI / 2 + h * 0.3;
            particles(def.p1(), center.x + Math.cos(a) * rr, center.y + h, center.z + Math.sin(a) * rr, 3, 0.2, 0.2, 0.2, 0.01);
        }
        particles(def.p2(), center.x, center.y + 1, center.z, 4, 1.2, 1.2, 1.2, 0.02);

        double strong = def.key().equals("agujero") ? 0.12 : 0.08;
        for (LivingEntity e : near(center.x, center.y, center.z, radius, 30, 12)) {
            if (protectedPlayer(e)) continue;
            Vec3 to = new Vec3(center.x - e.getX(), (center.y + 4) - e.getY(), center.z - e.getZ());
            double len = to.length();
            if (len < 0.5 || len > radius) continue;
            Vec3 dir = to.scale(1.0 / len);
            double lift = def.key().equals("tornado") ? 0.06 : 0.0;
            e.setDeltaMovement(e.getDeltaMovement().add(dir.x * strong, dir.y * strong * 0.5 + lift, dir.z * strong));
            e.hurtMarked = true;
            if (len < radius * 0.3 && ticks % 20 == 0) hit(e, def.damage());
        }
        if (ticks % 8 == 0 && def.impact() == Def.Impact.SINKHOLE && destroy()) sinkhole();
    }

    private void sinkhole() {
        double a = rnd.nextDouble() * Math.PI * 2, d = rnd.nextDouble() * radius * 0.3;
        int x = (int) (center.x + Math.cos(a) * d), z = (int) (center.z + Math.sin(a) * d);
        int y = surfaceY(x, z);
        for (int dy = 1; dy <= 3; dy++) {
            BlockPos p = new BlockPos(x, y - dy, z);
            if (canBreak(p)) level.setBlockAndUpdate(p, Blocks.AIR.defaultBlockState());
        }
    }
}
